import { useEffect, useState } from "react";
import axios from "axios";

function ListaUsuarios() {
  const [usuarios, setUsuarios] = useState([]);

  const cargarUsuarios = () => {
    axios.get("http://localhost:3001/usuarios")
      .then(res => setUsuarios(res.data))
      .catch(err => console.error(err));
  };

  useEffect(() => {
    cargarUsuarios();
  }, []);

  const eliminarUsuario = (id) => {
    axios.delete(`http://localhost:3001/usuarios/${id}`)
      .then(() => cargarUsuarios())
      .catch(err => console.error(err));
  };

  return (
    <div>
      <h2>Lista de Usuarios</h2>
      <table border="1">
        <thead>
          <tr>
            <th>ID</th><th>Nombre</th><th>Apellido</th><th>Dirección</th>
            <th>Teléfono</th><th>Celular</th><th>Fecha Nacimiento</th>
            <th>Email</th><th>Documento</th><th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          {usuarios.map(u => (
            <tr key={u.id}>
              <td>{u.id}</td><td>{u.nombre}</td><td>{u.apellido}</td>
              <td>{u.direccion}</td><td>{u.telefono}</td><td>{u.celular}</td>
              <td>{u.fecha_nacimiento}</td><td>{u.email}</td><td>{u.documento}</td>
              <td>
                {/* Para editar podrías abrir un componente EditarUsuario */}
                <button onClick={() => eliminarUsuario(u.id)}>Eliminar</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default ListaUsuarios;