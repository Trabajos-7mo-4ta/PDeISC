import { useState } from "react";
import axios from "axios";

function CrearUsuario() {
  const [form, setForm] = useState({
    nombre: "", apellido: "", direccion: "", telefono: "",
    celular: "", fecha_nacimiento: "", email: "", documento: ""
  });

  const handleChange = e => {
    setForm({...form, [e.target.name]: e.target.value});
  };

  const handleSubmit = e => {
    e.preventDefault();
    axios.post("http://localhost:3001/usuarios", form)
      .then(() => {
        alert("Usuario creado!");
        setForm({
          nombre: "", apellido: "", direccion: "", telefono: "",
          celular: "", fecha_nacimiento: "", email: "", documento: ""
        });
      })
      .catch(err => console.error(err));
  };

  return (
    <div>
      <h2>Crear Usuario</h2>
      <form onSubmit={handleSubmit}>
        <input name="nombre" value={form.nombre} onChange={handleChange} placeholder="Nombre" required />
        <input name="apellido" value={form.apellido} onChange={handleChange} placeholder="Apellido" required />
        <input name="direccion" value={form.direccion} onChange={handleChange} placeholder="Dirección" />
        <input name="telefono" value={form.telefono} onChange={handleChange} placeholder="Teléfono" />
        <input name="celular" value={form.celular} onChange={handleChange} placeholder="Celular" />
        <input type="date" name="fecha_nacimiento" value={form.fecha_nacimiento} onChange={handleChange} />
        <input name="email" value={form.email} onChange={handleChange} placeholder="Email" />
        <input name="documento" value={form.documento} onChange={handleChange} placeholder="Documento" />
        <button type="submit">Crear</button>
      </form>
    </div>
  );
}

export default CrearUsuario;