import { useState } from "react";
import ListaUsuarios from "./Components/ListaUsuarios.jsx";
import CrearUsuario from "./Components/CrearUsuario.jsx";

function App() {
  const [vista, setVista] = useState("lista"); // "lista" o "crear"

  return (
    <div>
      <h1>ABMLC Usuarios</h1>
      <button onClick={() => setVista("lista")}>Ver usuarios</button>
      <button onClick={() => setVista("crear")}>Crear usuario</button>

      {vista === "lista" && <ListaUsuarios />}
      {vista === "crear" && <CrearUsuario />}
    </div>
  );
}

export default App;