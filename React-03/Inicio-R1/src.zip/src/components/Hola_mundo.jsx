import "../App.css"

export default function Hola_mundo() {
  let mensaje="Hola Mundo";
    return (<div className="Contenedor">        
        <h1 >{mensaje}</h1>
    </div>
    );
}