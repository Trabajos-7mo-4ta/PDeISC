const tareasData = [
    {
        id: 1,
        titulo: "Tarea 1",
        descripcion: "Descripción corta de la tarea 1",
        fecha_creacion: "21/08/2025",
        estado: false
    },
    {
        id: 2,
        titulo: "Tarea 2",
        descripcion: "Descripción corta de la tarea 2",
        fecha_creacion: "21/08/2025",
        estado: false
    },

  ];