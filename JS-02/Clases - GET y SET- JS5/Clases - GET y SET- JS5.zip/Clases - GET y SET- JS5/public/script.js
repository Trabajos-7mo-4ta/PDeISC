// Selección de elementos del DOM
const formulario = document.getElementById("formularioAnimales");
const mensaje = document.getElementById("mensaje");
const tablaAnimales = document.getElementById("tablaAnimales");
const resultados = document.getElementById("resultados"); 

let zooAnimals = []; // Array para almacenar los animales

formulario.addEventListener("submit", (e) => {
    e.preventDefault(); 

   
    const IdAnimal = parseInt(document.getElementById("paramIdAnimal").value);
    const Nombre = document.getElementById("paramNombre").value;
    const JaulaNumero = parseInt(document.getElementById("paramJaulaNumero").value);
    const IdTypeAnimal = parseInt(document.getElementById("paramIdTypeAnimal").value);
    const Peso = parseInt(document.getElementById("paramPeso").value);

    // Solo pueden ingresarse 5 animales
    if (zooAnimals.length < 5) {
        zooAnimals.push(new CZooAnimal(IdAnimal, Nombre, JaulaNumero, IdTypeAnimal, Peso));
        mensaje.textContent = "Animal ingresado";  
    } else {
        mensaje.textContent = "Ya ingresaste 5 animales"; 
    }

    // Limpiar el formulario
    formulario.reset();

    // Mostrar tabla actualizada
    let tableHTML = "<h3>Lista de Animales</h3>";
    tableHTML += "<table border='1'><tr><th>ID</th><th>Nombre</th><th>Jaula</th><th>Tipo</th><th>Peso</th></tr>";

    zooAnimals.forEach(animal => {
        tableHTML += `<tr>
            <td>${animal.IdAnimal}</td>
            <td>${animal.nombre}</td>
            <td>${animal.JaulaNumero}</td>
            <td>${animal.IdTypeAnimal}</td>
            <td>${animal.peso}</td>
        </tr>`;
    });

    tableHTML += "</table>";
    tablaAnimales.innerHTML = tableHTML; // Actualiza la tabla en el HTML

    // Mostrar los resultados en la página 
    let resultadosHTML = "<h2>Resultados del Zoológico</h2>";

    const b = zooAnimals.filter(a => a.JaulaNumero === 5 && a.peso < 3).length;
    resultadosHTML += `<p><b>b)</b> Animales en jaula 5 con peso < 3kg: ${b}</p>`;

    const c = zooAnimals.filter(a => a.IdTypeAnimal === 1 && a.JaulaNumero >= 2 && a.JaulaNumero <= 5).length;
    resultadosHTML += `<p><b>c)</b> Felinos entre jaulas 2 a 5: ${c}</p>`;

    const d = zooAnimals.find(a => a.JaulaNumero === 4 && a.peso < 120);
    resultadosHTML += `<p><b>d)</b> Animal en jaula 4 con peso < 120: ${d ? d.nombre : "No encontrado"}</p>`;

    resultados.innerHTML = resultadosHTML; // Actualizar los resultados en el HTML
});

