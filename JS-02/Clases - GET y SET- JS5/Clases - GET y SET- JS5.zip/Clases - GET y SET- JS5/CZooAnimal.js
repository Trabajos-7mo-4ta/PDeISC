class CZooAnimal {
    constructor(IdAnimal, nombre, JaulaNumero, IdTypeAnimal, peso) {
        this.IdAnimal = IdAnimal;
        this.nombre = nombre;
        this.JaulaNumero = JaulaNumero;
        this.IdTypeAnimal = IdTypeAnimal;
        this.peso = peso;
    }

    // Getters 
    get IdAnimal() {
        return this._IdAnimal;
    }
    get nombre() {
        return this._nombre;
    }
    get JaulaNumero() {
        return this._JaulaNumero;
    }
    get IdTypeAnimal() {
        return this._IdTypeAnimal;
    }
    get peso() {
        return this._peso;
    }

    // Setters
    set IdAnimal(value) {
        this._IdAnimal = value;
    }
    set nombre(value) {
        this._nombre = value;
    }
    set JaulaNumero(value) {
        this._JaulaNumero = value;
    }
    set IdTypeAnimal(value) {
        this._IdTypeAnimal = value;
    }
    set peso(value) {
        this._peso = value;
    }
}
