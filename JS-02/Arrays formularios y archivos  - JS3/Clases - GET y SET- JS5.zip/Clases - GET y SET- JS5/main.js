const express = require("express");
const app = express();
const path = require("path");
const fs = require("fs");
const PORT = 3010;

// Lista en memoria para guardar los números
const listaNumeros = [];

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

app.post("/enviar", (req, res) => {
    const numero = parseInt(req.body.paramNumero);

    if (isNaN(numero)) {
        return res.status(400).send("Dato inválido");
    }

    if (listaNumeros.length >= 20) {
        return res.status(400).send("Ya se ingresaron 20 números");
    }

    listaNumeros.push(numero);
    res.status(200).send("Número agregado");
});

// Devuelve los numeros guardados
app.get("/numeros", (req, res) => {
    res.json(listaNumeros);
});

// Ruta para guardar los números en un archivo .txt
app.post("/guardar", (req, res) => {
    if (listaNumeros.length < 10) {
        return res.status(400).send("Debes ingresar al menos 10 números.");
    }

    const contenido = listaNumeros.join(", ");
    fs.writeFile("numeros.txt", contenido, (err) => {
        if (err) {
            console.error(err);
            return res.status(500).send("Error al guardar.");
        }
        res.send("El archivo 'numeros.txt' se creo correctamente!");
    });
});

// Se inicia el servidor
app.listen(PORT, () => {
    console.log(`Servidor corriendo en: http://localhost:${PORT}`);
});