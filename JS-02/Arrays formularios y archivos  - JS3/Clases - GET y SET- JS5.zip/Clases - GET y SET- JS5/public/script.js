// Elementos del DOM
const formulario = document.getElementById("formularioAnimales");
const listaAnimales = document.getElementById("listaAnimales");

const IdAnimal = parseInt(document.getElementById("paramIdAnimal").value);
const Nombre = document.getElementById("paramNombre").value;
const JaulaNumero = parseInt(document.getElementById("paramJaulaNumero").value);
const IdTypeAnimal = parseInt(document.getElementById("paramIdTypeAnimal").value);
const Peso = parseInt(document.getElementById("paramPeso").value);


let animalesGuardados = {};

formulario.addEventListener("submit", async (e) => {
    e.preventDefault();
    
    let animal=new CZooAnimal (IdAnimal,Nombre,JaulaNumero,IdTypeAnimal,Peso)

    animalesGuardados.push(animal);



});

