class CzooAnimal{
    constructor(IdAnimal,nombre,JaulaNumero,IdTypeAnimal,peso){
        this.IdAnimal=IdAnimal;
        this.nombre=nombre;
        this.JaulaNumero=JaulaNumero;
        this.IdTypeAnimal=IdTypeAnimal;
        this.peso=peso;

    }

    get IdAnimal(){
        return this.IdAnimal;
    }
    get nombre(){
        return this.nombre;
    }
    get JaulaNumero(){
        return this.JaulaNumero;
    }
    get IdTypeAnimal(){
        return this.IdTypeAnimal;
    }
    get peso(){
        return this.peso;
    }
}
