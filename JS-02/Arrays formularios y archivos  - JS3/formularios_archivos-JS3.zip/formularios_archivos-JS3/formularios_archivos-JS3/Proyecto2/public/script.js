const formularioArchivo = document.getElementById("formularioArchivo");
const listaUtiles = document.getElementById("listaNumerosUtiles");
const resumen = document.getElementById("resumenEstadisticas");
const mensajeEstado = document.getElementById("mensajeEstado");

// Al enviar el formulario, subir el archivo al servidor
formularioArchivo.addEventListener("submit", async (e) => {
    e.preventDefault();

    const archivo = document.getElementById("archivoTxt").files[0];
    const formData = new FormData();
    formData.append("archivoTxt", archivo);

    try {
        const res = await fetch("/subir", {
            method: "POST",
            body: formData
        });

        if (!res.ok) {
            const error = await res.text();
            mostrarMensaje(`Error: ${error}`);
            return;
        }

        const data = await res.json();

        // Limpiar la lista anterior
        listaUtiles.innerHTML = "";

        // Agregar los números útiles a la lista
        data.utiles.forEach(n => {
            const li = document.createElement("li");
            li.textContent = n;
            listaUtiles.appendChild(li);
        });


        resumen.innerHTML = `
            Total: ${data.total} <br>
            Útiles: ${data.utilesCount} <br>
            No útiles: ${data.noUtilesCount} <br>
            Porcentaje de útiles: ${data.porcentaje}%
        `;

        mostrarMensaje("Archivo procesado correctamente.");

    } catch (error) {
        mostrarMensaje("Error de conexión con el servidor.");
        console.error(error);
    }
});

// Muestra mensajes de estado en pantalla
function mostrarMensaje(texto) {
    mensajeEstado.textContent = texto;
}