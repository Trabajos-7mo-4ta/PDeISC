const express = require("express");
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const app = express();
const PORT = 3010;

// Configuración de multer para guardar archivos subidos temporalmente
const upload = multer({ dest: "uploads/" });

// Middleware para analizar formularios y servir archivos estáticos
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

// Ruta para recibir y procesar archivo .txt
app.post("/subir", upload.single("archivoTxt"), (req, res) => {
    const rutaArchivo = req.file.path;

    // Leer el contenido del archivo subido
    fs.readFile(rutaArchivo, "utf8", (err, contenido) => {
        if (err) {
            return res.status(500).send("Error al leer el archivo");
        }

        // Separar los números por comas, espacios o saltos de línea
        const listaNumeros = contenido
            .split(/[,\s\n]+/)
            .map(n => n.trim())
            .filter(n => /^\d+$/.test(n))
            .map(Number);

        // Filtrar los que empiezan y terminan con el mismo dígito
        const numerosUtiles = listaNumeros.filter(n => {
            const str = n.toString();
            return str[0] === str[str.length - 1];
        });

        const cantidadTotal = listaNumeros.length;
        const cantidadUtiles = numerosUtiles.length;
        const cantidadNoUtiles = cantidadTotal - cantidadUtiles;
        const porcentajeUtiles = ((cantidadUtiles / cantidadTotal) * 100).toFixed(2);

        // Preparar respuesta para el cliente
        const resultado = {
            utiles: numerosUtiles.sort((a, b) => a - b),
            total: cantidadTotal,
            utilesCount: cantidadUtiles,
            noUtilesCount: cantidadNoUtiles,
            porcentaje: porcentajeUtiles
        };

        // Guardar los números útiles en un nuevo archivo
        fs.writeFile("filtrados.txt", resultado.utiles.join(", "), (err) => {
            if (err) {
                console.error("Error al guardar 'filtrados.txt'");
            }
        });

        res.json(resultado);
    });
});

// Iniciar el servidor
app.listen(PORT, () => {
    console.log(`Servidor corriendo en: http://localhost:${PORT}`);
});