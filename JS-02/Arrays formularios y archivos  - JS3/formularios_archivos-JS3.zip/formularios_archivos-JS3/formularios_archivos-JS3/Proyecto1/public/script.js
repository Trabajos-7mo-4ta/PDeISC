// Elementos del DOM
const formulario = document.getElementById("formularioNumeros");
const listaNumeros = document.getElementById("listaNumeros");
const botonGuardar = document.getElementById("botonGuardar");
const campoNumero = document.getElementById("paramNumero");
const mensajeEstado = document.getElementById("mensajeEstado");

let cantidadIngresada = 0;

// Cargar lista inicial desde el servidor
fetch("/numeros")
    .then(res => res.json())
    .then(data => {
        data.forEach(numero => agregarNumeroALaLista(numero));
        cantidadIngresada = data.length;
        verificarSiPuedeGuardar();
    });

//Corrobora que se envie el formulario
formulario.addEventListener("submit", async (e) => {
    e.preventDefault();
    const numero = campoNumero.value;

    if (cantidadIngresada >= 20) {
        mostrarMensaje("No se pueden ingresar mas de 20 numeros.");
        return;
    }

    const datos = { paramNumero: numero };

    const response = await fetch("/enviar", {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded",
        },
        body: new URLSearchParams(datos)
    });

    if (response.ok) {
        agregarNumeroALaLista(numero);
        cantidadIngresada++;
        verificarSiPuedeGuardar();
        formulario.reset();
        mostrarMensaje("Se agrego el numero!");
    } else {
        const error = await response.text();
        mostrarMensaje(`Error: ${error}`);
    }
});

// Evento al hacer clic en el submit del formulario
botonGuardar.addEventListener("click", async () => {
    const res = await fetch("/guardar", { method: "POST" });
    const mensaje = await res.text();

    if (res.ok) {
        mostrarMensaje(mensaje);
    } else {
        mostrarMensaje(mensaje);
    }
});

// Agrega un número a la lista en pantalla
function agregarNumeroALaLista(numero) {
    const li = document.createElement("li");
    li.textContent = numero;
    listaNumeros.appendChild(li);
}

function verificarSiPuedeGuardar() {
    botonGuardar.disabled = cantidadIngresada < 10;
}

function mostrarMensaje(texto) {
    mensajeEstado.textContent = texto;
}