const express = require("express");
const app = express();
const path = require("path");
const PORT = 3020;
const productos = [];

app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

app.post('/agregar', (req, res) => {
    const producto = {
        deporte: req.body.deporte,
        herramienta: req.body.herramienta,
        precio: req.body.precio,
        cantidad: req.body.cantidad,
    };

    productos.push(producto);
    console.log(productos);

    res.status(200).send("OK");
});

app.get('/productos', (req, res) => {
    res.json(productos);
});

app.listen(PORT, () => {
    console.log(`Servidor corriendo en: http://127.0.0.1:${PORT}`);
});