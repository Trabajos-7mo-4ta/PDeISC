document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("formulario");
    const lista = document.getElementById("listaProductos");

    // Cargar productos al iniciar
    fetch("/productos")
        .then(res => res.json())
        .then(data => {
            data.forEach(p => {
                agregarProducto(p);
            });
        });

    form.addEventListener("submit", async (e) => {
        e.preventDefault();

        const datos = {
            deporte: document.getElementById("deporte").value,
            herramienta: document.getElementById("herramienta").value,
            precio: document.getElementById("precio").value,
            cantidad: document.getElementById("cantidad").value,
        };

        const response = await fetch("/agregar", {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded",
            },
            body: new URLSearchParams(datos)
        });

        if (response.ok) {
            agregarProducto(datos);
            form.reset();
        } else {
            alert("Error al agregar el producto");
        }
    });

    function agregarProducto(p) {
        const li = document.createElement("li");
        li.textContent = `${p.deporte} - ${p.herramienta} - $${p.precio} - Cantidad: ${p.cantidad}`;
        lista.appendChild(li);
    }
});