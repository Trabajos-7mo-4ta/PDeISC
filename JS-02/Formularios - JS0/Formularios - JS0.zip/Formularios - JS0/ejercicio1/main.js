const express = require("express");
const app = express();
const path = require("path");
const PORT = 3010;
const personas = [];

app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

app.post('/enviar', (req, res) => {
    const persona = {
        usuario: req.body.paramUsuario,
        email: req.body.paramEmail,
        contraseña: req.body.paramContraseña,
    };

    personas.push(persona);
    console.log(personas);

    res.status(200).send("OK"); // Respuesta simple para AJAX
});

app.get('/personas', (req, res) => {
    res.json(personas); // Ahora devolvemos los datos como JSON
});

app.listen(PORT, () => {
    console.log(`Servidor corriendo en: http://127.0.0.1:${PORT}`);
});