document.addEventListener("DOMContentLoaded", () => {
    const form = document.querySelector("form");
    const listaUsuarios = document.getElementById("listaUsuarios");

    // Cargar lista inicial desde el servidor
    fetch("/personas")
        .then(res => res.json())
        .then(data => {
            data.forEach(p => {
                const li = document.createElement("li");
                li.textContent = `${p.usuario} - ${p.email} - ${p.contraseña}`;
                listaUsuarios.appendChild(li);
            });
        });

    form.addEventListener("submit", async (e) => {
        e.preventDefault();

        const datos = {
            paramUsuario: document.getElementById("paramUsuario").value,
            paramEmail: document.getElementById("paramEmail").value,
            paramContraseña: document.getElementById("paramContraseña").value,
        };

        const response = await fetch("/enviar", {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded",
            },
            body: new URLSearchParams(datos)
        });

        if (response.ok) {
            const nuevoItem = document.createElement("li");
            nuevoItem.textContent = `${datos.paramUsuario} - ${datos.paramEmail} - ${datos.paramContraseña}`;
            listaUsuarios.appendChild(nuevoItem);
            form.reset();
        } else {
            alert("Error al agregar el usuario");
        }
    });
});