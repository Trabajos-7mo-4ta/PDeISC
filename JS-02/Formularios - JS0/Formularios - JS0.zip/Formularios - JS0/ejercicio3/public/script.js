document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("formulario");
    const lista = document.getElementById("listaPersonas");
    const mensaje = document.getElementById("mensaje");
    const hijosSelect = document.getElementById("tieneHijos");
    const campoCantidad = document.getElementById("cantidadHijos");

    hijosSelect.addEventListener("change", () => {
        campoCantidad.style.display = (hijosSelect.value === "si") ? "block" : "none";
    });

    // Cargar personas al iniciar
    fetch("/personas")
        .then(res => res.json())
        .then(data => {
            data.forEach(p => agregarPersona(p));
        });

    form.addEventListener("submit", async (e) => {
        e.preventDefault();
        
        // Validación JS adicional
        const nombre = document.getElementById("nombre").value.trim();
        const apellido = document.getElementById("apellido").value.trim();
        const edad = document.getElementById("edad").value;
        const fechaNacimiento = document.getElementById("fechaNacimiento").value;
        const sexo = document.getElementById("sexo").value;
        const documento = document.getElementById("documento").value;

        if (!nombre || !apellido || !edad || !fechaNacimiento || !sexo || !documento) {
            mostrarMensaje("Por favor complete los campos obligatorios", false);
            return;
        }

        const datos = Object.fromEntries(new FormData(form).entries());

        const response = await fetch("/agregar", {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded",
            },
            body: new URLSearchParams(datos),
        });

        if (response.ok) {
            agregarPersona(datos);
            mostrarMensaje("Persona registrada correctamente", true);
            form.reset();
            campoCantidad.style.display = "none";
        } else {
            const texto = await response.text();
            mostrarMensaje("Error: " + texto, false);
        }
    });

    function agregarPersona(p) {
        const li = document.createElement("li");
        li.textContent = `${p.nombre} ${p.apellido}`;
        lista.appendChild(li);
    }

    function mostrarMensaje(msg, exito) {
        mensaje.textContent = msg;
        mensaje.style.color = exito ? "green" : "red";
    }
});