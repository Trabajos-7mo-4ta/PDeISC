const express = require("express");
const app = express();
const path = require("path");
const PORT = 3030;
const personas = [];

app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

app.post('/agregar', (req, res) => {
    const p = req.body;

    // Validación básica del lado del servidor
    if (!p.nombre || !p.apellido || !p.edad || !p.fechaNacimiento || !p.sexo || !p.documento) {
        return res.status(400).send("Faltan datos obligatorios");
    }

    personas.push(p);
    console.log(personas);
    res.status(200).send("Persona agregada correctamente");
});

app.get('/personas', (req, res) => {
    res.json(personas);
});

app.listen(PORT, () => {
    console.log(`Servidor corriendo en: http://127.0.0.1:${PORT}`);
});