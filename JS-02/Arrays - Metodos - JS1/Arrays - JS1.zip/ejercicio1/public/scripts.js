const resultadoFruta = document.getElementById('resultado-fruta');
const resultadoAmigo = document.getElementById('resultado-amigo');
const resultadoNumero = document.getElementById('resultado-numero');

// Función para mostrar array como lista
function mostrarLista(titulo, array) {
    const lista = array.map(item => `<li>${item}</li>`).join('');
    return `<hr><h4>${titulo}:</h4><ul>${lista}</ul>`;
}

// Frutas
document.getElementById('formFruta').addEventListener('submit', async (e) => {
    e.preventDefault();
    const fruta = document.getElementById('fruta').value;

    const res = await fetch('/agregar-fruta', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fruta })
    });

    const data = await res.json();

    let mensajeHTML = '';
    if (data.error) {
        mensajeHTML = `<p style="color:red;">${data.error}</p>`;
    } else if (data.mensaje) {
        mensajeHTML = `<p style="color:green;">${data.mensaje}</p>`;
    }

    // Mostrar siempre la lista de frutas, aunque haya error
    resultadoFruta.innerHTML = mensajeHTML + mostrarLista('Frutas', data.frutas);
});

// Amigos
document.getElementById('formAmigo').addEventListener('submit', async (e) => {
    e.preventDefault();
    const amigo = document.getElementById('amigo').value;

    const res = await fetch('/agregar-amigo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amigo })
    });

    const data = await res.json();

    let mensajeHTML = '';
    if (data.error) {
        mensajeHTML = `<p style="color:red;">${data.error}</p>`;
    } else if (data.mensaje) {
        mensajeHTML = `<p style="color:green;">${data.mensaje}</p>`;
    }

    // Mostrar siempre la lista de amigos, aunque haya error
    resultadoAmigo.innerHTML = mensajeHTML + mostrarLista('Amigos', data.amigos);
});

// Números
document.getElementById('formNumero').addEventListener('submit', async (e) => {
    e.preventDefault();
    const numero = document.getElementById('numero').value;

    const res = await fetch('/agregar-numero', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ numero })
    });

    const data = await res.json();
    if (data.error) {
        resultadoNumero.innerHTML = `<p style="color:red;">Error: ${data.error}</p>`;
    } else {
        const mensaje = `<h4>${data.mensaje}</h4>`;
        resultadoNumero.innerHTML = mensaje + mostrarLista('Números', data.numeros);
    }
});