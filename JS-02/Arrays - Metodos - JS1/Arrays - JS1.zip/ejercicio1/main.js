const e = require('express');
const express = require('express');
const path = require('path');
const app = express();
const port = 3000;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Servir archivos estáticos
app.use(express.static(path.join(__dirname, 'public')));

// Datos en memoria
let frutas = [];
let amigos = [];
let numeros = [];

// Rutas API

app.post('/agregar-fruta', (req, res) => {
    const { fruta } = req.body;
    if (frutas.length < 3) {
        if (fruta) frutas.push(fruta);

        // Nuevo: mensaje cuando se llega a 3 frutas
        const mensaje = frutas.length === 3 ? '¡Has ingresado 3 frutas!' : null;
        res.json({ frutas, mensaje });
    } else {
        return res.json({ error: 'No puedes agregar más de 3 frutas!' });
    }
    

});

app.post('/agregar-amigo', (req, res) => {
    const { amigo } = req.body;
    if (amigos.length < 3) {
        if (amigo) amigos.push(amigo);

        // Nuevo: mensaje cuando se llega a 3 amigos
        const mensaje = amigos.length === 3 ? '¡Has ingresado 3 amigos!' : null;
        res.json({ amigos, mensaje });
    } else {
        return res.json({ error: 'No puedes agregar más de 3 amigos!' });
    }
});

app.post('/agregar-numero', (req, res) => {
    const numero = parseFloat(req.body.numero);

    if (isNaN(numero)) {
        return res.status(400).json({ error: 'El valor enviado no es un número válido' });
    }

    if (numeros.length === 0) {
        numeros.push(numero);
        return res.json({ mensaje: 'Primer número agregado', numeros });
    }

    const ultimo = numeros[numeros.length - 1];

    if (numero > ultimo) {
        numeros.push(numero);
        return res.json({ mensaje: 'Número agregado (mayor que el anterior)', numeros });
    } else {
        return res.json({ mensaje: 'Número NO agregado (menor o igual al anterior)', numeros });
    }
});

// Iniciar servidor
app.listen(port, () => {
    console.log(`Servidor en http://localhost:${port}`);
});
