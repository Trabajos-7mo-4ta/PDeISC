function mostrarComponente(componente) {
    const contenedor = document.getElementById('contenedor');
    contenedor.innerHTML = ""; // vaciamos todo el conetinido html en la seccion del id 
  
    if (componente === 'componente1') {
      const btn = document.createElement('button');
      btn.textContent = "Haz click aquí";
      btn.onclick = () => alert("¡Clickeaste el botón!");
      contenedor.appendChild(btn);
  
    } else if (componente === 'componente2') {
      const div = document.createElement('div');
      div.textContent = "Pasa el mouse por aquí";
      div.onmouseover = () => div.style.backgroundColor = "yellow";
      div.onmouseout = () => div.style.backgroundColor = "transparent";
      div.style.padding = "20px";
      div.style.border = "1px solid black";
      contenedor.appendChild(div);
  
    } else if (componente === 'componente3') {
      const input = document.createElement('input');
      input.type = "text";
      input.placeholder = "Escribe algo";
      input.onkeyup = () => console.log("Tecla presionada");
      contenedor.appendChild(input);
  
    } else if (componente === 'componente4') {
      const img = document.createElement('img');
      img.src = "imagenes/imagen1.png";
      img.alt = "Imagen";
      img.onclick = () => alert("¡Clickeaste la imagen!");
      img.style.cursor = "pointer";
      contenedor.appendChild(img);
  
    } else if (componente === 'componente5') {
      const p = document.createElement('p');
      p.textContent = "Haz doble click para cambiar el texto.";
      p.ondblclick = () => p.textContent = "¡Texto cambiado!";
      contenedor.appendChild(p);
    }
  }