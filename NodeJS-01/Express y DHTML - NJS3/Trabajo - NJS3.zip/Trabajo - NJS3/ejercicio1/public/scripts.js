let h1Agregado = null;//Creo la variable para crear un h1, esto para despues poder preguntar con una condicion si es que esta creado, y asi modificarlo despues
var imagenAgregada = null;//Hago lo mismo con la variable para crear una imagen

function agregarH1() {
    if (!h1Agregado) {//Si la el h1 no esta creado, se seguira con la linea de codigo
    h1Agregado = document.createElement('h1');//se crea la variable con un h1
    h1Agregado.textContent = "Hola DOM";//Le agregamos texto al h1
    document.getElementById('contenedor').appendChild(h1Agregado);//metemos el h1 en el id "contenedor" que se encuentra en el index.html
  }
}

function cambiarH1() {//Creamos la funcion para cambiar el h1. Si el h1 contiene un "hola DOM", se cambiara a "Chau DOM" y viceversa
    if (h1Agregado.textContent=="Hola DOM") {
        h1Agregado.textContent = "Chau DOM";
    }
    else if(h1Agregado.textContent=="Chau DOM"){
        h1Agregado.textContent= "Hola DOM";
    }
}

function cambiarColorH1() {//En esta funcion cambiamos el color del h1.
  if (h1Agregado.style.color=="red") {//Si el color del h1 es rojo, se cambiara a negro
    h1Agregado.style.color = "black";
  }
  else {
    h1Agregado.style.color="red";//Si el color del h1 no es rojo(es negro), se cambiara a rojo
  }
}

function agregarImagen() {//Con esta funcion crearemos una imagen, de una forma parecida a como creamos el h1
  if (!imagenAgregada) {//Si todavia no se creo ninguna imagen, se seguira con el codigo
    imagenAgregada = document.createElement('img');//se crea la variable que contiene un elemento img
    imagenAgregada.src = "imagenes/imagen1.png";//Se le agrega la ubicacion a la imagen
    imagenAgregada.style.width = "500px";//se le da un tamaño
    imagenAgregada.style.height="auto";
    document.getElementById('contenedor').appendChild(imagenAgregada);//Agregamos la imagen al id "contenedor" mencionado anteriormente
  }
}

function cambiarImagen() {//Con la siguiente funcion se cambiara la ubicacion de la imagen
    if (imagenAgregada.src.includes("imagen1.png")) {//Si la ubicacion de la imagen, contiene el archivo imagen1.png, se canbiara a otra ubicacion
      imagenAgregada.src = "imagenes/imagen2.png";
    } else if (imagenAgregada.src.includes("imagen2.png")) {//Lo mismo pero cambiando de la imagen 2 a la 1
      imagenAgregada.src = "imagenes/imagen1.png";
    }
  }

function cambiarTamanioImagen() {//Dependiendo de el tamaño de la imagen, se cambiara entre uno o otro
  if (imagenAgregada.style.width=="500px") {
    imagenAgregada.style.width = "100px";
    imagenAgregada.style.height = "auto";
  }
  else if (imagenAgregada.style.width=="100px") {
    imagenAgregada.style.width = "500px";
    imagenAgregada.style.height = "auto";
  }
}

function irApagina(ruta){//Se crea la funcion para volver a la pagina principal
    window.location.href =ruta;
}