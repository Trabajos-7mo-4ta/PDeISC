var msj1="Hola mundo.";//Creo las 2 variables con mensajes
var msj2="Fin.";

console.log(msj1);//Muestro las variables por pantalla
console.log(msj2);