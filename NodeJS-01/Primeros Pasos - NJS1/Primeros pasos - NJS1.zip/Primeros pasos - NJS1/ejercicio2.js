var suma=4+5;
var resta=3-6;
var multiplicacion=2*7;
var division=20/4;

console.log("El resultado de la suma 4+5 es: ",suma);
console.log("El resultado de la resta 3-6 es: ",resta);
console.log("El resultado de la multiplicacion 2*7 es: ",multiplicacion);
console.log("El resultado de la division 20/4 es: ",division);