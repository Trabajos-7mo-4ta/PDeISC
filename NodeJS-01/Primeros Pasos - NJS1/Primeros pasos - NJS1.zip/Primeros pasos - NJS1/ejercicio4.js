import { calculos } from './calculos.js';//Importo la funcion calculos, desde el archivo "calculos.js"

calculos();//Ejecuto la funcion calculos en el archivo actual