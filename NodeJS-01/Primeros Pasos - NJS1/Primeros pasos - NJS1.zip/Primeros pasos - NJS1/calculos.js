export function calculos(){//Creo la funcion calculos y la exporto
    var suma=5+3;//Creo todas las variables
    var resta=8-6;
    var multiplicacion=3*11;
    var division=30/5;

    console.log("El resultado de la suma 5+3 es: ",suma);//Muestro por pantalla
    console.log("El resultado de la resta 8-6 es: ",resta);
    console.log("El resultado de la multiplicacion 3*11 es: ",multiplicacion);
    console.log("El resultado de la division 30/5 es: ",division);
}
