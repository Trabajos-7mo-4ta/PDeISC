//Creamos la funcion para el modulo "tiempo.js"
exports.tiempoActual = function () {
    return Date();
  };