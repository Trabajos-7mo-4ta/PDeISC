//Creamos la funcion para el modulo "saludo.js"
exports.crearSaludo= function(){
    console.log("Hola mundo");
}