//Creamos las funciones para el modulo "matematicas.js"
exports.crearSuma = function (a,b) {
    s=a+b;
    return s;
  };

exports.crearResta = function (a,b) {
    r=a-b;
    return r;
  };

exports.crearMultiplicacion = function (a,b) {
    m=a*b;
    return m;
  };

exports.crearDivision = function (a,b) {
    d=a/b;
    return d;
  };